close all; clc; clear all;

%% Data Load
Ts = 0.01;
Tf = 0.02;

Fs = 16000;

Ns = Fs * Ts;
Nf = Fs * Tf;

Dir = "D:\과제\음성신호처리\segmented\2\";

Files = dir(Dir);
Files = Files(3:end);
File_name = "kdigits2-3.wav";

[SPK, ~] = audioread(sprintf('%s%s', Dir, File_name));

Total_Time = length(SPK) / Fs;

SPK_Time = 0:1/Fs:Total_Time - 1 / Fs;

figure();
plot(SPK_Time, SPK);
axis tight;
xlabel('Time [s]');
ylabel('Amplitude');
title('Waveform');

SPK_temp = SPK(Fs*0.3:Fs*0.8, 1);
SPK_time_temp = SPK_Time(Fs*0.3:Fs*0.8);

figure();
plot(SPK_time_temp, SPK_temp);
axis tight;
xlabel('Time [s]');
ylabel('Amplitude');
title('Waveform');

%% #1

NFFT = Ns * 2;
Overlap_Samples = 80;

[S, F, T, P] = spectrogram(SPK_temp, hamming(NFFT), Overlap_Samples, NFFT, Fs);

P = 10*log10(abs(P));

figure();
imagesc(T, F, P); shading interp;
axis xy; colorbar;
xlabel('Time [s]');
ylabel('Amplitude');
title('Spectrogram (dB)');

%% #2
stft_1 = spectrogram(SPK_temp, hamming(Ns*2), Overlap_Samples, NFFT, Fs);
magnitude = abs(stft_1);
log_spectrogram = 20*log10(magnitude);

figure();
imagesc([0, length(SPK_temp)/Fs], [0, Fs/2], log_spectrogram);
axis xy; colorbar;
xlabel('Time [s]');
ylabel('Amplitude');
title('Spectrogram (dB)');

%% #3

% 어떻게 하는지 모르겠습니다 ㅜㅜ 죄송합니다 ㅜㅜ

%% #4

[S,F,T] = stft(SPK_temp, Fs,'Window',hamming(NFFT),'OverlapLength',Overlap_Samples,'FFTLength',NFFT);
figure();
surf(T,F,(abs(S)/max(max(abs(S))))); shading interp; view(2);
axis tight;

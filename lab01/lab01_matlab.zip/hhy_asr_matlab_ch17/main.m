clear all; close all; clc;

traindata = cell(1,10);
for i=0:9
    temp = cell(1,8);%3�� �н� 
    for j=0:7
     fname = sprintf('./segmented/%d/kdigits%d-%d.wav',i,i, j);
     x = audioread(fname);
     temp{1,j+1}=x';
   end
   traindata{1,i+1} = temp;
end

testdata = cell(1,2);
for i=0:9
    temp = cell(1,2);%3�� �н� 
    for j=8:9
     fname = sprintf('./segmented/%d/kdigits%d-%d.wav',i,i, j);
     x = audioread(fname);
     temp{1,j + 1 - 8}=x';
   end
   testdata{1,i+1} = temp;
end

%%
hmm = cell(1,10);
% train
for i = 1:length(traindata)
	sample = [];
	for k = 1:length(traindata{i})
		x = filter([1 -0.9375], 1, traindata{i}{k});
		sample(k).data = melcepst(x,16000,'M',12,24,320,160);
	end
	%hmm{i}=train(sample,[3 3 3 3]);
    hmm{i}=train(sample,[3 3 3 3]);
end

%%
% test
for i = 1:length(testdata)
    for k = 1:length(testdata{i})
        x = filter([1 -0.9375], 1, testdata{i}{k});
        m = melcepst(x,16000,'M',12,24,320,160);
        for j = 1:10
            pout(j) = viterbi(hmm{j}, m);
        end
        [d, n] = max(pout);
        
        fprintf('word number %d is recognized as %d\n', i-1,n - 1)
    end
end



% 
% for i = 1:10
% 	fname = sprintf('%d1a.wav',i-1);
% 	x = audioread(fname);
% 	x = filter([1 -0.9375], 1, x);
% 	m = melcepst(x,16000,'M',12,24,256,80);
% 	for j = 1:10
% 		pout(j) = viterbi(hmm{j}, m);
% 	end
% 	[d,n] = max(pout);
% 
%     fprintf('word number %d is recognized as %d\n', i-1,n)
% end